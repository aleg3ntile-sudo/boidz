#include "boidz.hpp"
#include <random>

namespace boidz
{

  Coords operator+(const Coords &p, const Coords &q)
  {
    return {p.x + q.x, p.y + q.y};
  }

  sf::ConvexShape createBoidShape(float size)
  {
    sf::ConvexShape shape;
    shape.setPointCount(3);

    shape.setPoint(0, sf::Vector2f(size, 0.f));
    shape.setPoint(1, sf::Vector2f(-size * 0.6f, -size * 0.5f));
    shape.setPoint(2, sf::Vector2f(-size * 0.6f, size * 0.5f));
    shape.setFillColor(sf::Color(100, 200, 255));

    shape.setOrigin(0.f, 0.f);

    return shape;
  }

  std::vector<SingleBoid> generate_flock (int N) {
    
    std::vector<SingleBoid> flock{};
    std::random_device r;
    std::default_random_engine eng(r());
    std::uniform_real_distribution<float> px{0.f, 200.f};
    std::uniform_real_distribution<float> py{0.f, 200.f};
    std::uniform_real_distribution<float> vel{-50.f, 50.f};
  
    for (int j{0}; j != N; ++j)
    {
      Coords p{px(eng), py(eng)};
      Coords v{vel(eng), vel(eng)};
      SingleBoid b = SingleBoid(p, v, j);
      flock.push_back(b);
    }
  
    return flock;
    }

    SingleBoid generate_hunter() {
      SingleBoid hunter{{400.f, 300.f}, {0.f, 0.f}, -1};
      hunter.setColor(sf::Color(255, 100, 100));
      return hunter;
    }

  SingleBoid::SingleBoid()
      : position{}, velocity{}, boid_id(0), shape{createBoidShape(5.f)} {}

  SingleBoid::SingleBoid(Coords p, Coords v, int i)
      : position(p), velocity(v), boid_id(i), shape{createBoidShape(5.f)} {}

  int SingleBoid::getboid_id() const { return boid_id; }

  Coords SingleBoid::getPosition() const { return position; }

  Coords SingleBoid::getVelocity() const { return velocity; }

  void SingleBoid::update_Position_in_time(float time)
  {
    position.x = position.x + time * velocity.x;
    position.y = position.y + time * velocity.y;
  }

  void SingleBoid::update_Shape()
  {
    float angle = static_cast<float>(std::atan2(velocity.y, velocity.x) * 180 / M_PI);
    shape.setPosition(sf::Vector2f(position.x, position.y));
    shape.setRotation(angle);
  }

  void SingleBoid::update_Velocity_with_rules(
      Coords updated_velocity)
  {
    velocity = updated_velocity;
  }

  void SingleBoid::BorderRestriction(float width, float height)
  {
    if (position.x < 0.f)
      position.x += width;
    else
    {
      if (position.x >= width)
      {
        position.x -= width;
      }
    }

    if (position.y < 0.f)
      position.y += height;
    else
    {
      if (position.y >= height)
      {
        position.y -= height;
      }
    }
  }

  void SingleBoid::SpeedRestriction(float speed_limit)
  {
    float speed = std::sqrt(velocity.x * velocity.x + velocity.y * velocity.y);
    if (speed > speed_limit)
    {
      velocity.x = velocity.x * speed_limit / speed;
      velocity.y = velocity.y * speed_limit / speed;
    }
  }

  void SingleBoid::draw(sf::RenderWindow &window) const { window.draw(shape); }

  void SingleBoid::setColor(const sf::Color &c) { shape.setFillColor(c); }

  

} // namespace boidz

#include "stats.hpp"
#include "rules.hpp"
#include <vector>
#include <numeric>

namespace boidz
{
  Stats::Stats(size_t max) :
        max_points{max} {}

    void Stats::add(float mean, float std_dev) {
        means.push_back(mean);
        standard_deviations.push_back(std_dev);
        trim_to_max_size(means, max_points);
        trim_to_max_size(standard_deviations, max_points);
    }
    const std::vector<float>& Stats::get_means() const { return means;}
    const std::vector<float>& Stats::get_standard_deviations() const { return standard_deviations;}
  std::vector<float> get_vector_of_speeds(std::vector<SingleBoid> const &f)
  {
    std::vector<float> vector_of_speeds{};
    for (const auto &b : f)
    {
      float speed = std::sqrt(b.getVelocity().x * b.getVelocity().x +
                              b.getVelocity().y * b.getVelocity().y);
      vector_of_speeds.push_back(speed);
    }
    return vector_of_speeds;
  }

  float mean_speed(const std::vector<float> &v)
  {
    float mean_speed{0.f};
    if (v.size() != 0)
    {
      mean_speed = std::accumulate(v.begin(), v.end(), 0.f) / static_cast<float>(v.size());
    }
    return mean_speed;
  }

  std::vector<float> get_vector_of_distances(std::vector<SingleBoid> const &f)
  {
    std::vector<float> vector_of_distances{};
    float boidz_distance{0.f};
    if (f.size() != 0)
    {
      for (const auto &b : f)
      {
        for (const auto &c : f)
        {
          if (b.getboid_id() < c.getboid_id())
          {
            boidz_distance = get_distance(b, c);
            vector_of_distances.push_back(boidz_distance);
          }
        }
      }
    }  
      return vector_of_distances;
  }

  float mean_distance(std::vector<float> const &v)
  {
    float mean_distance{0.f};
    if (v.size() != 0)
    {
      mean_distance = (std::accumulate(v.begin(), v.end(), 0.f) /
                       static_cast<float>(v.size()));  
    }
    return mean_distance;
  }

  float standard_deviation(std::vector<float> const &v)
  {
    float standard_deviation{0.f};
    if (v.size() != 0)
    {
      float mean = std::accumulate(v.begin(), v.end(), 0.f) / static_cast<float>(v.size());
      float sum_of_squared_deviations = 0.f;
      for (const auto &x : v)
      {
        sum_of_squared_deviations += static_cast<float>(std::pow(x - mean, 2));
      }
      standard_deviation = std::sqrt(sum_of_squared_deviations / static_cast<float>(v.size()));
      return standard_deviation;
    }
    else
    {
      return standard_deviation;
    }
  }

  void trim_to_max_size(std::vector<float> &v, size_t max_size) {
    if (v.size() > max_size) {
      v.erase(v.begin(), v.begin() +
              static_cast<long int>(v.size() - max_size));
    }
  }
  void update_stats(const std::vector<SingleBoid> &f, Stats& s, Stats& d) {
    auto speeds = get_vector_of_speeds(f);
      auto distances = get_vector_of_distances(f);
      s.add(mean_speed(speeds), standard_deviation(speeds));
      d.add(mean_distance(distances), standard_deviation(distances));
  }

} // namespace boidz

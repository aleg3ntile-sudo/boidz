#ifndef WINDOWUTILS_HPP
#define WINDOWUTILS_HPP

#include <SFML/Graphics.hpp>
#include <vector>

namespace boidz
{

    struct GraphResources
    {
        sf::VertexArray axis;

        sf::RectangleShape box;

        sf::CircleShape speed_point;

        sf::CircleShape distance_point;

        sf::Text speed_label;

        sf::Text distance_label;

        GraphResources()
        : axis(sf::PrimitiveType::Lines, 4),
          box({260.f,100.f}),
          speed_point(2.f),
          distance_point(2.f)
    {}
    
    };

    GraphResources create_graph_resources(const sf::Font &font);
    void close_if_requested(sf::RenderWindow &window);
    void draw_graph(sf::RenderWindow &window, const sf::VertexArray &axis,
                    const sf::RectangleShape &box, sf::Text &label,
                    sf::CircleShape &point,
                    const std::vector<float> &data,
                    const std::vector<float> &deviations,
                    const std::string &value_name);
    void draw_points(sf::RenderWindow &window,
                     sf::CircleShape &point,
                     const std::vector<float> &data);
    void draw_label(sf::Text &label,
                    const std::vector<float> &data,
                    const std::vector<float> &errors,
                    const std::string &name);

}

#endif
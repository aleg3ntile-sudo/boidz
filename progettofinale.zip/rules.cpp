#include "rules.hpp"
#include <cassert>
#include <cmath>

namespace boidz
{

  float get_distance(const SingleBoid &b1, const SingleBoid &b2)
  {
    Coords a = b1.getPosition();
    Coords b = b2.getPosition();
    assert(std::isfinite(a.x) && std::isfinite(a.y));
    assert(std::isfinite(b.x) && std::isfinite(b.y));
    float d_x = a.x - b.x;
    float d_y = a.y - b.y;
    float distance = static_cast<float>(std::sqrt(d_x * d_x + d_y * d_y));

    assert(distance >= 0.f);
    return distance;
  }

  bool check_critical_distance(float d_s, const SingleBoid &b1,
                               const SingleBoid &b2)
  {
    assert(d_s >= 0.f);
    Coords a = b1.getPosition();
    Coords b = b2.getPosition();
    float d_x = a.x - b.x;
    float d_y = a.y - b.y;
    bool critical_distance =
        d_x * d_x + d_y * d_y <= d_s * d_s;
    return critical_distance;
  }

  bool check_neighbours(float d, const SingleBoid &b1,
                        const SingleBoid &b2)
  {
    Coords a = b1.getPosition();
    Coords b = b2.getPosition();
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    return dx * dx + dy * dy <= d * d;
  }

  std::vector<SingleBoid> get_neighbours(float distance,
                                         const SingleBoid &s, const std::vector<SingleBoid> &f)
  {
    assert(distance >= 0.f);
    std::vector<SingleBoid> neighbours{};

    for (const auto &x : f)
    {
      if (s.getboid_id() != x.getboid_id() &&
          check_neighbours(distance, s, x))
      {
        neighbours.push_back(x);
      }
    }
    assert(neighbours.size() <= f.size());
    return neighbours;
  }

  Coords separation(const Parameters &par, const std::vector<SingleBoid> &neighbours,
                    const SingleBoid &a)
  {
    float sum_x{0.f};
    float sum_y{0.f};
    assert(par.d >= 0.f);

    for (
      const auto &b : neighbours)
    {
      if (check_critical_distance(par.d_s, a, b))
      {
        sum_x += b.getPosition().x - a.getPosition().x;
        sum_y += b.getPosition().y - a.getPosition().y;
      }
    }

    Coords v_separation{-(par.s * sum_x), -(par.s * sum_y)};
    assert(par.s >= 0.f);
    assert(std::isfinite(v_separation.x) && std::isfinite(v_separation.y));
    return v_separation;
  }

  Coords alignment(const Parameters &par, const std::vector<SingleBoid> &neighbours,
                   const SingleBoid &s)
  {
    Coords v_alignment;
    Coords v_sum{0.f, 0.f};
    auto n = neighbours.size();

    for (const auto &b : neighbours)
    {
      v_sum.x += b.getVelocity().x;
      v_sum.y += b.getVelocity().y;
    }
    if (neighbours.size() >= 1)
    {
      v_alignment = Coords{par.a * ((v_sum.x / static_cast<float>(n)) - s.getVelocity().x),
                           par.a * ((v_sum.y / static_cast<float>(n)) - s.getVelocity().y)};
      assert(par.a >= 0.f);
      assert(std::isfinite(v_alignment.x) && std::isfinite(v_alignment.y));
      return v_alignment;
    }
    else
    {
      v_alignment = Coords{0.0f, 0.0f};
      return v_alignment;
    }
  }

  Coords cohesion(const Parameters &par, const std::vector<SingleBoid> &neighbours,
                  const SingleBoid &s)
  {
    Coords com{0.f, 0.f};
    Coords v_cohesion;
    auto n = static_cast<float>(neighbours.size());
    for (const auto &b : neighbours)
    {
      com.x += b.getPosition().x;
      com.y += b.getPosition().y; 
    }

    if (neighbours.size() >= 1)
    {
      v_cohesion = Coords{par.c * (com.x / n - s.getPosition().x),
                          par.c * (com.y / n - s.getPosition().y)};
      assert(par.c >= 0.);
      assert(std::isfinite(v_cohesion.x) && std::isfinite(v_cohesion.y));
      return v_cohesion;
    }
    else
    {
      v_cohesion = Coords{0.0f, 0.0f};
      return v_cohesion;
    }
  }

  Coords hunt_the_flock(const SingleBoid &hunter, const std::vector<SingleBoid> &flock,
                        const Parameters &par)
  {
    Coords com{0.f, 0.f};
    Coords v_hunt;
    auto s = static_cast<float>(flock.size());
    for (const auto &b : flock)
    {
      com.x += b.getPosition().x;
      com.y += b.getPosition().y;
    }
    if (flock.size() > 0)
    {
      v_hunt = Coords{par.h * (com.x / s - hunter.getPosition().x),
                      par.h * (com.y / s - hunter.getPosition().y)};
      assert(par.h >= 0.f);
      assert(std::isfinite(v_hunt.x) && std::isfinite(v_hunt.y));
    }
    else
    {
      v_hunt = Coords{0.f, 0.f};
    }
    return v_hunt;
  }

  Coords hunt_neighbours(const SingleBoid &hunter, const std::vector<SingleBoid> &flock,
                         const Parameters &par)
  {
    Coords v_chase_neighbours{};
    for (const auto &b : flock)
    {
      if (check_neighbours(par.h_n, hunter, b))
      {
        v_chase_neighbours =
            Coords{par.h * (b.getPosition().x - hunter.getPosition().x),
                   par.h * (b.getPosition().y - hunter.getPosition().y)};
        return v_chase_neighbours;
      }
    }
    return v_chase_neighbours;
  }

  Coords hunter_repulsion(const SingleBoid &hunter, const SingleBoid &prey,
                          const Parameters &par)
  {
    Coords v_prey;
    if (check_critical_distance(par.d, prey, hunter))
    {
      v_prey = Coords{-(par.p * (hunter.getPosition().x - prey.getPosition().x)),
                      -(par.p * (hunter.getPosition().y - prey.getPosition().y))};
      assert(par.p >= 0.f);
      assert(std::isfinite(v_prey.x) && std::isfinite(v_prey.y));
    }
    else
    {
      v_prey = Coords{0.f, 0.f};
    }
    return v_prey;
  }

  Coords create_velocity_with_rules(const Parameters &par,
                                    const std::vector<SingleBoid> &flock,
                                    const SingleBoid &b,
                                    const SingleBoid &hunter)
  {
    auto neighbours = get_neighbours(par.d, b, flock);
    return b.getVelocity() + separation(par, neighbours, b) +
           alignment(par, neighbours, b) +
           cohesion(par, neighbours, b) +
           hunter_repulsion(hunter, b, par);
  }

  void update_flock( std::vector<SingleBoid> &f, const Parameters &pars, const SingleBoid &hunter, float time){

    std::vector<Coords> updated_velocities(f.size());
      for (size_t i = 0; i < f.size(); ++i)
      {
        updated_velocities[i] = create_velocity_with_rules(pars, f,
                                                           f[i], hunter);
      }

      for (size_t i = 0; i < f.size(); ++i)
      {
        f[i].update_Velocity_with_rules(updated_velocities[i]);
        f[i].update_Position_in_time(time);
        f[i].BorderRestriction(800.f, 600.f);
        f[i].SpeedRestriction(130);
        f[i].update_Shape();
      }
  }    

  void update_hunter(SingleBoid &hunter, const std::vector<SingleBoid> &flock, const Parameters &params, float time) {
    {
      Coords new_hunt_velocity = hunt_the_flock(hunter, flock, params) +
                                 hunt_neighbours(hunter, flock, params);
      hunter.update_Velocity_with_rules(new_hunt_velocity);
      hunter.update_Position_in_time(time);
      hunter.BorderRestriction(800.f, 600.f);
      hunter.SpeedRestriction(100.f);
      hunter.update_Shape();
    }
  }

} // namespace boidz

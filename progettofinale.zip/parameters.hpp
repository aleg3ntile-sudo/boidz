#ifndef PARAMETERS_HPP
#define PARAMETERS_HPP

#include<string>
#include<iostream>
#include<stdexcept>

namespace boidz {
struct Parameters {
  float d;   // parametro vicini
  float d_s; // paramtero vicini critici
  float s;   // parametro di separazione
  float a;   // parametro di allineamento
  float c;   // parametro di coesione
  float h = 1.f;  // parametro di caccia dello stormo
  float h_n = 200.f; // parametro di caccia dei vicini
  float p = 1.f;   // parametro di preda
  int n; //dimensione stormo
};

template <typename T>
T read_parameter(const std::string &name, T min, T max)
{
  T p;

  std::cout << "Insert " << name << "between " << min << " and " << max << '\n';
  std::cin >> p;
  if (p < min || p > max)
  {
    throw std::runtime_error(name + "out of range");
  }
  return p;
}

Parameters read_parameters_from_input ();

}

#endif
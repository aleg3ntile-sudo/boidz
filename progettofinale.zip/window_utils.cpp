#include "window_utils.hpp"
#include <algorithm>
#include<iostream>
namespace boidz
{
    GraphResources create_graph_resources(const sf::Font& font)
    {
        GraphResources g{};
        float margin_x = 50.f;
        float margin_y = 50.f;

        sf::Vector2f origin{
            margin_x,
            600.f - margin_y};

        auto white = sf::Color::White;
        auto black = sf::Color::Black;

        g.speed_point.setFillColor(sf::Color::Red);

        g.distance_point.setFillColor(sf::Color::Green);

        g.axis[0].position = origin;
        g.axis[0].color = white;

        g.axis[1].position = {450.f, origin.y};
        g.axis[1].color = white;

        g.axis[2].position = origin;
        g.axis[2].color = white;

        g.axis[3].position = {origin.x, 50.f};
        g.axis[3].color = white;

        g.box.setPosition({180.f, 5.f});

        g.box.setFillColor(white);

        g.speed_label.setFont(font);

        g.distance_label.setFont(font);

        g.speed_label.setCharacterSize(20);

        g.distance_label.setCharacterSize(20);

        g.speed_label.setFillColor(black);

        g.distance_label.setFillColor(black);

        g.speed_label.setPosition({190.f, 10.f});

        g.distance_label.setPosition({190.f, 10.f});

        return g;
    }

    void close_if_requested(sf::RenderWindow &window)
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window.close();
            }
        }
    }

    void draw_graph(sf::RenderWindow &window, const sf::VertexArray &axis,
                    const sf::RectangleShape &box, sf::Text &label,
                    sf::CircleShape &point,
                    const std::vector<float> &data,
                    const std::vector<float> &deviations,
                    const std::string &value_name)
    {
        window.clear();

        window.draw(axis);

        draw_points(window, point, data);

        draw_label(label, data, deviations, value_name);

        window.draw(box);

        window.draw(label);

        window.display();
    }

    void draw_points(sf::RenderWindow &window,
                     sf::CircleShape &point,
                     const std::vector<float> &data)
    {
        float left = 50.f;
        float right = 450.f;
        float bottom = 550.f;
        float top = 50.f;

        float width = right - left;
        float step = (data.size() > 1)
                         ? width / static_cast<float>(data.size() - 1)
                         : 0.f;

        for (size_t i = 0; i < data.size(); ++i)
        {
            float x = left + static_cast<float>(i) * step;
            float y = bottom - data[i];
            y = std::clamp(y, top, bottom);
            sf::CircleShape p = point;
            p.setPosition(x, y);

            window.draw(p);
        }
    }

    void draw_label(sf::Text &label,
                    const std::vector<float> &data,
                    const std::vector<float> &errors,
                    const std::string &name)
    {
        if (data.size() != 0 && errors.size() != 0)
        {

            label.setString(
                name + " = " + std::to_string(data.back()) +
                "\nstd.dev. = " + std::to_string(errors.back()));
        }
    }

}

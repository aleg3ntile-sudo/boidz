#ifndef STATS_HPP
#define STATS_HPP

#include "boidz.hpp"

namespace boidz
{
    class Stats
    {

        std::vector<float> means;
        std::vector<float> standard_deviations;
        size_t max_points;

    public:
        Stats(size_t max);
        void add(float mean, float std_dev);
        const std::vector<float> &get_means() const;
        const std::vector<float> &get_standard_deviations() const;
    };

    struct SimulationStats
    {
        Stats speed;

        Stats distance;
    };
    std::vector<float> get_vector_of_speeds(std::vector<SingleBoid> const &f);
    float mean_speed(std::vector<float> const &v);
    std::vector<float> get_vector_of_distances(std::vector<SingleBoid> const &f);
    float mean_distance(std::vector<float> const &v);
    float standard_deviation(std::vector<float> const &v);
    void trim_to_max_size(std::vector<float> &v, size_t max_size);
    void update_stats(const std::vector<SingleBoid>& flock, Stats& s, Stats& d);

} // namespace boidz

#endif // STATS_HPP

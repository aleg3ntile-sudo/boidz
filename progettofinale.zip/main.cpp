#include "rules.hpp"
#include "stats.hpp"
#include "window_utils.hpp"
#include <random>

using namespace boidz;

int main()
{
  Parameters params{};

  try
  {
    params = read_parameters_from_input();
  }

  catch (const std::runtime_error &e)
  {
    std::cerr << "Error" << '\n';
    return EXIT_FAILURE;
  }

  auto flock = generate_flock(params.n);

  auto hunter = generate_hunter();

  sf::RenderWindow window_boids(sf::VideoMode(800, 600), "Boids");
  window_boids.setFramerateLimit(60);

  sf::RenderWindow window_speed(sf::VideoMode(500, 600), "Speed");
  window_speed.setFramerateLimit(60);
  window_speed.setPosition(sf::Vector2i(12, 300));

  sf::RenderWindow window_distance(sf::VideoMode(500, 600), "Distance");
  window_distance.setFramerateLimit(60);
  window_distance.setPosition(sf::Vector2i(1422, 300));

  sf::Clock clock;
  sf::Font font;
  if (!font.loadFromFile(
    std::string(RESOURCES_PATH) + "font.ttf"))
{
throw std::runtime_error(
    "Failed to load font");
}
  auto resources = create_graph_resources(font);
  const size_t max_points = 450;
  Stats speed_stats(max_points);
  Stats distance_stats(max_points);

  float timer = 0.f;
  const float delay = 5.f;
  while (window_boids.isOpen() || window_speed.isOpen() || window_distance.isOpen())
  {
    close_if_requested(window_boids);
    close_if_requested(window_speed);
    close_if_requested(window_distance);

    if (window_boids.isOpen())
    {
      float dt = clock.restart().asSeconds();

      timer += dt;

      update_flock(flock, params, hunter, dt);

      if (timer >= delay)
      {

        update_hunter(hunter, flock, params, dt);
      }

      update_stats(flock, speed_stats, distance_stats);

      window_boids.clear(sf::Color(15, 17, 26));
      for (auto &b : flock)
      {
        b.draw(window_boids);
      }
      hunter.draw(window_boids);
      window_boids.display();
    }

    if (window_speed.isOpen())
    {
      draw_graph(window_speed, resources.axis, resources.box, resources.speed_label, resources.speed_point, speed_stats.get_means(),
                 speed_stats.get_standard_deviations(), "Mean speed");
    }

    if (window_distance.isOpen())
    {
      draw_graph(window_distance, resources.axis, resources.box, resources.distance_label, resources.distance_point, distance_stats.get_means(),
                 distance_stats.get_standard_deviations(), "Distance");
    }
  }
}

#ifndef RULES_HPP
#define RULES_HPP

#include "boidz.hpp"
 
namespace boidz {

float get_distance(const SingleBoid &b1, const SingleBoid &b2);

bool check_critical_distance(float d_s, const SingleBoid &b1,
                             const SingleBoid &b2);

bool check_neighbours(float d, const SingleBoid &b1,
                      const SingleBoid &b2);

std::vector<SingleBoid>get_neighbours(float distance,
                                       const SingleBoid &s, const std::vector<SingleBoid> &f);

Coords separation(const Parameters &par, const std::vector<SingleBoid> &neighbours,
                                  const SingleBoid &a);

Coords alignment(const Parameters &par, const std::vector<SingleBoid> &neighbours,
                                 const SingleBoid &s);

Coords cohesion(const Parameters &par, const std::vector<SingleBoid> &neighbours,
                                const SingleBoid &s);

Coords hunt_the_flock(const SingleBoid &hunter, const std::vector<SingleBoid> &flock,
            const Parameters &par);

Coords hunt_neighbours(const SingleBoid &hunter, const std::vector<SingleBoid> &flock,
    const Parameters &par);

Coords hunter_repulsion(const SingleBoid &hunter, const SingleBoid &prey,
                        const Parameters &par);

Coords create_velocity_with_rules(const Parameters &par,
                                                  const std::vector<SingleBoid> &flock,
                                                  const SingleBoid &b,
                                                  const SingleBoid &hunter);

void update_flock( std::vector<SingleBoid> &f, const Parameters &pars, const SingleBoid &hunter, float dt );                                                  

void update_hunter(SingleBoid &hunter, const std::vector<SingleBoid> &flock, const Parameters &params, float time);

} // namespace boidz
#endif

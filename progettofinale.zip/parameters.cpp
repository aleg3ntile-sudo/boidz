#include "parameters.hpp"

namespace boidz{
Parameters read_parameters_from_input () {

    Parameters params{};
  params.d = read_parameter("Neighbours distance ", 20.f, 100.f);
  params.d_s = read_parameter("Critical distance ", 5.f, 25.f);
  params.s = read_parameter("Separation parameter ", 0.5f, 5.f);
  params.a = read_parameter("Alignment parameter ", 0.05f, 1.f);
  params.c = read_parameter("Cohesion parameter ", 0.01f, 0.05f);
  params.n = read_parameter("Flock size ", 1, 200);
  
  return params;
}

}